package ca.weblite.codename1.io.tar;


/**
 *  @author Kamran
 *  
 */
public class TarUtils {

	public TarUtils() {
	}

	/**
	 *  Determines the tar file size of the given folder/file path
	 *  
	 *  @param path
	 *  @return
	 *  @throws IOException 
	 */
	public static long calculateTarSize(String path) {
	}
}
